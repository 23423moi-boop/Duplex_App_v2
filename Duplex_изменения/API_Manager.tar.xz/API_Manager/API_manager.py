from flask import Flask, render_template, request, redirect, url_for, flash
import requests
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

API_BASE_URL = 'http://localhost:5000'

# Глобальный кэш
_patients_cache = []
_cache_valid = False

def validate_patient(data):
    """
    Валидация данных пациента.
    Возвращает кортеж (is_valid, error_message, error_code)
    """
    errors = []
    error_code = None

    # Проверка обязательных полей
    if not data.get('patient_id'):
        errors.append("ID пациента обязательно")
        error_code = error_code or "1"
    if not data.get('personal_info', {}).get('last_name'):
        errors.append("Фамилия обязательна")
        error_code = error_code or "1"
    if not data.get('personal_info', {}).get('first_name'):
        errors.append("Имя обязательно")
        error_code = error_code or "1"
    if not data.get('personal_info', {}).get('birth_date'):
        errors.append("Дата рождения обязательна")
        error_code = error_code or "1"
    else:
        try:
            datetime.strptime(data['personal_info']['birth_date'], '%Y-%m-%d')
        except ValueError:
            errors.append("Неверный формат даты рождения (требуется ГГГГ-ММ-ДД)")
            error_code = error_code or "2"

    if not data.get('contact', {}).get('phone'):
        errors.append("Телефон обязателен")
        error_code = error_code or "1"
    if not data.get('medical', {}).get('diagnosis'):
        errors.append("Диагноз обязателен")
        error_code = error_code or "1"
    if not data.get('admission', {}).get('department'):
        errors.append("Отделение обязательно")
        error_code = error_code or "1"

    email = data.get('contact', {}).get('email')
    if email and '@' not in email:
        errors.append("Неверный формат email")
        error_code = error_code or "2"

    if not errors:
        return True, "", ""
    else:
        error_message = "; ".join(errors)
        return False, error_message, error_code or "99"

def fetch_patients(force=False):
    """Получить список пациентов из API с кэшированием."""
    global _patients_cache, _cache_valid
    if not force and _cache_valid:
        return _patients_cache
    try:
        response = requests.get(f'{API_BASE_URL}/patients')
        response.raise_for_status()
        _patients_cache = response.json()
        _cache_valid = True
        return _patients_cache
    except requests.exceptions.RequestException as e:
        flash(f'Ошибка при получении данных: {e}', 'error')
        return []

def get_patient_from_cache(patient_id):
    """Найти пациента в кэше по ID."""
    for patient in _patients_cache:
        if patient.get('patient_id') == patient_id:
            return patient
    return None

def send_patient_to_api(data, method='post', patient_id=None):
    """Отправить данные в API (POST или PUT)."""
    try:
        if method == 'post':
            response = requests.post(f'{API_BASE_URL}/patients', json=data)
        elif method == 'put':
            response = requests.put(f'{API_BASE_URL}/patients/{patient_id}', json=data)
        else:
            return None
        if response.status_code in (200, 201):
            return response.json()
        else:
            error_msg = response.json().get('error', 'Неизвестная ошибка') if response.headers.get('content-type') == 'application/json' else 'Ошибка сервера'
            flash(f'Ошибка API: {error_msg}', 'error')
            return None
    except requests.exceptions.RequestException as e:
        flash(f'Ошибка соединения с API: {e}', 'error')
        return None

def delete_patient_via_api(patient_id):
    """Удалить пациента через API."""
    try:
        response = requests.delete(f'{API_BASE_URL}/patients/{patient_id}')
        if response.status_code == 200:
            return True
        else:
            error_msg = response.json().get('error', 'Ошибка удаления') if response.headers.get('content-type') == 'application/json' else 'Ошибка сервера'
            flash(f'Ошибка API: {error_msg}', 'error')
            return False
    except requests.exceptions.RequestException as e:
        flash(f'Ошибка соединения с API: {e}', 'error')
        return False

@app.route('/')
def index():
    patients = fetch_patients(force=True)
    return render_template('index.html', patients=patients)

@app.route('/add', methods=['GET', 'POST'])
def add_patient():
    if request.method == 'POST':
        data = {
            "patient_id": request.form['patient_id'],
            "personal_info": {
                "first_name": request.form['first_name'],
                "last_name": request.form['last_name'],
                "middle_name": request.form.get('middle_name', ''),
                "birth_date": request.form['birth_date'],
                "gender": request.form['gender'],
                "blood_type": request.form.get('blood_type', '')
            },
            "contact": {
                "phone": request.form['phone'],
                "email": request.form.get('email', ''),
                "address": request.form.get('address', '')
            },
            "medical": {
                "diagnosis": request.form['diagnosis'],
                "allergies": [x.strip() for x in request.form.get('allergies', '').split(',') if x.strip()],
                "chronic_diseases": [x.strip() for x in request.form.get('chronic_diseases', '').split(',') if x.strip()],
                "current_medications": [x.strip() for x in request.form.get('current_medications', '').split(',') if x.strip()]
            },
            "admission": {
                "date": request.form['admission_date'],
                "department": request.form['department'],
                "doctor": request.form.get('doctor', ''),
                "emergency_contact": request.form.get('emergency_contact', '')
            },
            "errors": {"error": "", "error_code": ""}
        }

        is_valid, error_msg, error_code = validate_patient(data)
        if not is_valid:
            data['errors']['error'] = error_msg
            data['errors']['error_code'] = error_code
            flash(error_msg, 'error')
            return render_template('form.html', patient=data, mode='add')

        result = send_patient_to_api(data, method='post')
        if result:
            flash('Пациент успешно добавлен', 'success')
            return redirect(url_for('index'))
        else:
            return render_template('form.html', patient=data, mode='add')

    empty_patient = {
        "patient_id": "",
        "personal_info": {
            "first_name": "", "last_name": "", "middle_name": "",
            "birth_date": "", "gender": "male", "blood_type": ""
        },
        "contact": {"phone": "", "email": "", "address": ""},
        "medical": {"diagnosis": "", "allergies": [], "chronic_diseases": [], "current_medications": []},
        "admission": {"date": "", "department": "", "doctor": "", "emergency_contact": ""},
        "errors": {"error": "", "error_code": ""}
    }
    return render_template('form.html', patient=empty_patient, mode='add')

@app.route('/edit/<patient_id>', methods=['GET', 'POST'])
def edit_patient(patient_id):
    if request.method == 'POST':
        data = {
            "patient_id": patient_id,
            "personal_info": {
                "first_name": request.form['first_name'],
                "last_name": request.form['last_name'],
                "middle_name": request.form.get('middle_name', ''),
                "birth_date": request.form['birth_date'],
                "gender": request.form['gender'],
                "blood_type": request.form.get('blood_type', '')
            },
            "contact": {
                "phone": request.form['phone'],
                "email": request.form.get('email', ''),
                "address": request.form.get('address', '')
            },
            "medical": {
                "diagnosis": request.form['diagnosis'],
                "allergies": [x.strip() for x in request.form.get('allergies', '').split(',') if x.strip()],
                "chronic_diseases": [x.strip() for x in request.form.get('chronic_diseases', '').split(',') if x.strip()],
                "current_medications": [x.strip() for x in request.form.get('current_medications', '').split(',') if x.strip()]
            },
            "admission": {
                "date": request.form['admission_date'],
                "department": request.form['department'],
                "doctor": request.form.get('doctor', ''),
                "emergency_contact": request.form.get('emergency_contact', '')
            },
            "errors": {"error": "", "error_code": ""}
        }

        is_valid, error_msg, error_code = validate_patient(data)
        if not is_valid:
            data['errors']['error'] = error_msg
            data['errors']['error_code'] = error_code
            flash(error_msg, 'error')
            return render_template('form.html', patient=data, mode='edit')

        result = send_patient_to_api(data, method='put', patient_id=patient_id)
        if result:
            flash('Данные пациента обновлены', 'success')
            return redirect(url_for('index'))
        else:
            return render_template('form.html', patient=data, mode='edit')

    # GET - получаем данные из кэша
    patients_list = fetch_patients()  # загружаем кэш, если пуст
    patient = get_patient_from_cache(patient_id)
    if patient is None:
        flash('Пациент не найден', 'error')
        return redirect(url_for('index'))
    return render_template('form.html', patient=patient, mode='edit')

@app.route('/delete/<patient_id>', methods=['POST'])
def delete_patient(patient_id):
    if delete_patient_via_api(patient_id):
        flash('Пациент удалён', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5050)